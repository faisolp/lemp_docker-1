# docker_wordpress_nginx_mariadb
Fully Dockerized Wordpress site leveraging Nginx, MariaDB, and PHP7.1

You can find an indepth set of instructions and a comprehensive tutorial here: http://outofmyhead.olssonandjones.com/2017/11/15/docker-wordpress-site-with-nginx/

It goes into great detail with regard to just about every possible configuration setting in this Docker project.
